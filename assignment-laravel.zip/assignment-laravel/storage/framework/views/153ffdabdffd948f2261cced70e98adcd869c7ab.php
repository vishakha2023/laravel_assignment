<!-- App core JavaScript-->
<script src="<?php echo e(asset('js/app.js')); ?>"></script>

<!-- Custom scripts for all pages-->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>





<?php /**PATH C:\xampp\htdocs\assignment-laravel\resources\views/auth/includes/scripts.blade.php ENDPATH**/ ?>