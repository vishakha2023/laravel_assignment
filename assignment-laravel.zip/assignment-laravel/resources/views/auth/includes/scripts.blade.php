<!-- App core JavaScript-->
<script src="{{asset('js/app.js')}}"></script>

<!-- Custom scripts for all pages-->
{{-- <script src="{{asset('admin/js/sb-admin-2.min.js')}}"></script> --}}
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>





